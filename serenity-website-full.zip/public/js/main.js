// small UI helpers
document.addEventListener('DOMContentLoaded', () => {
  // set all year spans
  const year = new Date().getFullYear();
  document.querySelectorAll('[id^="year"]').forEach(el => el.textContent = year);
});
