\
require('dotenv').config();
const express = require('express');
const path = require('path');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const fs = require('fs');
const cors = require('cors');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000;

// ensure folders exist
if (!fs.existsSync(path.join(__dirname, 'uploads'))) fs.mkdirSync(path.join(__dirname, 'uploads'));
if (!fs.existsSync(path.join(__dirname, 'data'))) fs.mkdirSync(path.join(__dirname, 'data'));

// SQLite DB setup
const dbFile = path.join(__dirname, 'data', 'bookings.db');
const db = new sqlite3.Database(dbFile);
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    phone TEXT,
    service TEXT,
    start DATETIME,
    end DATETIME,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
});

// Nodemailer transporter (if configured)
let transporter = null;
if (process.env.SMTP_HOST && process.env.SMTP_USER) {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || "587", 10),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
  // verify connection
  transporter.verify().then(() => {
    console.log('SMTP transporter ready');
  }).catch(err => {
    console.log('SMTP transporter configuration problem:', err.message);
    transporter = null;
  });
}

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Simple static serving for public except admin protected assets
app.use('/static', express.static(path.join(__dirname, 'public')));

// Multer for uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'uploads')),
  filename: (req, file, cb) => {
    const safe = Date.now() + '-' + file.originalname.replace(/\s+/g, '_');
    cb(null, safe);
  }
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } }); // up to 50MB

// Basic admin auth middleware (HTTP Basic)
function requireAdmin(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) {
    res.set('WWW-Authenticate', 'Basic realm="Admin Area"');
    return res.status(401).send('Authentication required.');
  }
  const parts = auth.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Basic') return res.status(400).send('Bad authorization header');
  const creds = Buffer.from(parts[1], 'base64').toString('utf8').split(':');
  const user = creds[0] || '';
  const pass = creds[1] || '';
  if (user === process.env.ADMIN_USER && pass === process.env.ADMIN_PASS) return next();
  return res.status(403).send('Forbidden');
}

// Serve public pages (non-static) - index and main pages
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/about.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'about.html')));
app.get('/services.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'services.html')));
app.get('/pricing.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'pricing.html')));
app.get('/contact.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'contact.html')));
app.get('/booking.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'booking.html')));

// Admin UI (protected)
app.get('/admin.html', requireAdmin, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// API: upload endpoint
app.post('/api/upload', upload.single('taxfile'), async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });
  // Note: In production, validate file types and scan for malware

  // send confirmation email if transporter configured
  try {
    if (transporter && req.body.email) {
      await transporter.sendMail({
        from: process.env.SMTP_USER,
        to: req.body.email,
        subject: 'Serenity Tax Solutions — File received',
        text: `We received your document (${req.file.originalname}). Thank you.`
      });
    }
  } catch (err) {
    console.error('Email send failed:', err.message);
  }

  res.json({ success: true, filename: req.file.filename, originalname: req.file.originalname });
});

// Helper: check overlap
function hasOverlap(startIso, endIso, cb) {
  const sql = `SELECT COUNT(*) as cnt FROM bookings WHERE NOT (end <= ? OR start >= ?)`;
  db.get(sql, [startIso, endIso], (err, row) => {
    if (err) return cb(err);
    cb(null, row.cnt > 0);
  });
}

// API: create booking
app.post('/api/book', async (req, res) => {
  const { name, email, phone, service, start, end, notes } = req.body;
  if (!name || !email || !start || !end) {
    return res.status(400).json({ success: false, message: 'Missing required fields' });
  }
  // basic overlap check
  hasOverlap(start, end, (err, overlap) => {
    if (err) return res.status(500).json({ success: false, message: 'DB error' });
    if (overlap) return res.status(409).json({ success: false, message: 'Time slot not available' });

    const stmt = db.prepare(`INSERT INTO bookings (name,email,phone,service,start,end,notes) VALUES (?,?,?,?,?,?,?)`);
    stmt.run(name, email, phone || '', service || '', start, end, notes || '', async function(err) {
      if (err) return res.status(500).json({ success: false, message: 'DB insert failed' });

      // send confirmation email to client and notify admin
      try {
        if (transporter) {
          // to client
          await transporter.sendMail({
            from: process.env.SMTP_USER,
            to: email,
            subject: 'Serenity Tax Solutions — Booking confirmed',
            text: `Thanks ${name}. Your booking (ID ${this.lastID}) for ${service} on ${start} was received. We'll follow up with details.`
          });
          // to admin
          if (process.env.ADMIN_EMAIL) {
            await transporter.sendMail({
              from: process.env.SMTP_USER,
              to: process.env.ADMIN_EMAIL,
              subject: `New booking received (ID ${this.lastID})`,
              text: `New booking:\\n\\nName: ${name}\\nEmail: ${email}\\nService: ${service}\\nStart: ${start}\\nEnd: ${end}\\nNotes: ${notes || '(none)'}`
            });
          }
        }
      } catch (err) {
        console.error('Email notification error:', err.message);
      }

      return res.json({ success: true, bookingId: this.lastID });
    });
  });
});

// API: list bookings (admin only)
app.get('/api/admin/bookings', requireAdmin, (req, res) => {
  db.all('SELECT * FROM bookings ORDER BY start ASC LIMIT 1000', (err, rows) => {
    if (err) return res.status(500).json({ success: false, message: 'DB error' });
    res.json({ success: true, bookings: rows });
  });
});

// API: download uploaded file (admin only)
app.get('/api/admin/download', requireAdmin, (req, res) => {
  const file = req.query.file;
  if (!file) return res.status(400).send('file param required');
  const filepath = path.join(__dirname, 'uploads', path.basename(file));
  if (!fs.existsSync(filepath)) return res.status(404).send('File not found');
  res.download(filepath);
});

// fallback to index for unknown routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
