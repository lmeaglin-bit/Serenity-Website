Serenity Tax Solutions — Full package

What's included:
 - Express server with SQLite bookings and Multer uploads
 - Admin UI (HTTP Basic Auth) at /admin.html
 - Email confirmations using SMTP/nodemailer (configure SMTP_* in .env)
 - Calendly embed on booking page (set CALENDLY_URL in .env or replace placeholder in public/booking.html)
 - Protected download endpoint for uploaded files: /api/admin/download?file=FILENAME (requires admin auth)

Calendly embed (exact iframe snippet you can paste into any HTML):
<!-- Calendly inline widget -->
<div class="calendly-inline-widget" data-url="https://calendly.com/your-calendly" style="min-width:320px;height:630px;"></div>
<script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>

Admin:
 - Set ADMIN_USER and ADMIN_PASS in your environment (.env)
 - Visit /admin.html; your browser will prompt for credentials
 - From admin UI you can view bookings
 - To download uploaded files use /api/admin/download?file=FILENAME (admin auth required)

Run locally:
 - npm install
 - copy .env.example to .env and set values
 - npm start
 - open http://localhost:3000

Security notes:
 - This is a demo-ready codebase but not hardened for production.
 - Use HTTPS, strong admin credentials, and a secure mail provider for production.
